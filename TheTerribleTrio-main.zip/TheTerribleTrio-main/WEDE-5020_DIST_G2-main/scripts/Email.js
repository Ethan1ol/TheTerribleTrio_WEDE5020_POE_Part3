function validation() {
    // Clear previous error messages
    document.getElementById('nameError').textContent = '';
    document.getElementById('emailError').textContent = '';
    document.getElementById('messageError').textContent = '';
    document.getElementById('PhonenumberError').textContent = '';

    // Get form values
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();
    const Phonenumber = document.getElementById('phonenumber').value.trim(); 

    let isValid = true;

    // Validate name
    if (name === '') {
        document.getElementById('nameError').textContent = 'Name is required.';
        isValid = false;
    } else if (name.length < 5) {
        document.getElementById('nameError').textContent = 'Name must contain more than 5 characters.';
        isValid = false;
    } else if (!/^[a-zA-Z\s]+$/.test(name)) {
        document.getElementById('nameError').textContent = 'Name must contain only letters and spaces.';
        isValid = false;
    }

    // Validate email
    if (email === '') {
        document.getElementById('emailError').textContent = 'Email is required.';
        isValid = false;
    } else if (!validateEmail(email)) {
        document.getElementById('emailError').textContent = 'Please enter a valid email address.';
        isValid = false;
    }

    // Validate message
    if (message === '') {
        document.getElementById('messageError').textContent = 'Comments/Suggestions are required.';
        isValid = false;
    } else if (message.length < 10) {
        document.getElementById('messageError').textContent = 'Message must be at least 10 characters long.';
        isValid = false;
    }

    // Validate phone number
    if (Phonenumber === '') {
        document.getElementById('PhonenumberError').textContent = 'Phone number is required.';
        isValid = false;
    } else if (!validatePhoneNumber(Phonenumber)) {
        document.getElementById('PhonenumberError').textContent = 'Enter a valid phone number.';
        isValid = false;
    }

    return isValid; // Return true if valid, false if invalid
}

// Function to validate email format
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; 
    return re.test(String(email).toLowerCase());
}

// Function to validate phone number format
function validatePhoneNumber(phone) {
    const re = /^\d{10}$/; 
    return re.test(String(phone));
}

