document.getElementById('toggleButton').addEventListener('click', function() {
    const nav = document.getElementById('nav');
    nav.classList.toggle('show');

    // Calculate height for animation effect
    if (nav.classList.contains('show')) {
        nav.style.maxHeight = nav.scrollHeight + "px"; // Set maxHeight to scrollHeight for animation
    } else {
        nav.style.maxHeight = "0"; // Collapse to 0 when hiding
    }
});