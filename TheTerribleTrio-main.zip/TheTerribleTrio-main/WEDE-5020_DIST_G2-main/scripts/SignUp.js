document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById('signupForm');
    
    form.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent form submission

        // Clear previous error messages
        clearErrors();

        let valid = true;

        // Validate first name
        const nameInput = document.getElementById('name');
        if (nameInput.value.trim() === '') {
            showError('nameError', 'First name is required.');
            valid = false;
        } else if (nameInput.value.length < 2) { // Check length properly
            showError('nameError', 'Must have more than 2 characters.'); // Corrected the error ID
            valid = false;
        }

        // Validate last name
        const surnameInput = document.getElementById('Surname');
        if (surnameInput.value.trim() === '') {
            showError('SurnameError', 'Last name is required.');
            valid = false;
        } else if (surnameInput.value.length < 2) { // Fixed variable name typo
            showError('SurnameError', 'Must have more than 2 characters.'); // Corrected the error ID
            valid = false;
        }

        // Validate date of birth
        const bdateInput = document.getElementById('bdate');
        if (bdateInput.value === '') {
            showError('bdateError', 'Date of birth is required.');
            valid = false;
        } else {
            const birthDate = new Date(bdateInput.value);
            const age = new Date().getFullYear() - birthDate.getFullYear();
            const monthDiff = new Date().getMonth() - birthDate.getMonth();
            if (monthDiff < 0 || (monthDiff === 0 && new Date().getDate() < birthDate.getDate())) {
                age--;
            }
            if (age < 18) {
                showError('bdateError', 'Must be over 18.');
                valid = false;
            }
        }

        // Validate email
        const emailInput = document.getElementById('Email');
        if (emailInput.value.trim() === '') {
            showError('EmailError', 'Email is required.');
            valid = false;
        } else if (!validateEmail(emailInput.value)) {
            showError('EmailError', 'Please enter a valid email address.');
            valid = false;
        }

       
        const phoneInput = document.getElementById('PhoneNumber');
        if (phoneInput.value.trim() === '') {
            showError('PhoneNumberError', 'Phone number is required.');
            valid = false;
        } else if (!validatePhoneNumber(phoneInput.value)) {
            showError('PhoneNumberError', 'Please enter a valid phone number (format: 123-456-7890).');
            valid = false;
        }

        if (valid) {
            alert('Form submitted successfully!');
               
                window.location.href = 'home.html'; 
            }
           
           
        }
    );

    function showError(elementId, message) {
        const errorElement = document.getElementById(elementId);
        errorElement.textContent = message;
    }

    function clearErrors() {
        const errorElements = document.querySelectorAll('.error');
        errorElements.forEach(errorElement => {
            errorElement.textContent = '';
        });
    }

    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(String(email).toLowerCase());
    }

    function validatePhoneNumber(phone) {
        const re = /^\d{3}-\d{3}-\d{4}$/; // Format: 1234567890
        return re.test(phone);
}});
